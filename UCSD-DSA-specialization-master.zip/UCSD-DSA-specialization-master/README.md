# UCSD-DSA-specialization
Programming Assignments and Solutions of the Specialization of Data Structures and Algorithms offered by University of California San Diego & National Research University Higher School of Economics

Please go through these only if you are stuck anywhere in this course or you want to practice/revise all problems. Otherwise you are not honouring the Coursera Honor Code. 
