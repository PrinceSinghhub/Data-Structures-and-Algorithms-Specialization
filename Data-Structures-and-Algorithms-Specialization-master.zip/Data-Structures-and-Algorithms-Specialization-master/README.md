# Data-Structures-and-Algorithms-Specialization
This specialisation is a mix of theory and practice, and is created by UC San Diego. I will be posting the python codes of all the programming assignments and the algorithms that are taught in the class.

I am learning algorithmic techniques for solving various computational problems and will implement about 100 algorithmic coding problems in python. The creaters have invested over 3000 hours into designing challenges as an alternative to multiple choice questions that you usually find in MOOCs.

For each algorithm we have to develop and implement, they have designed multiple tests to check its correctness and running time — we will have to debug our programs without even knowing what these tests are! I believe this is the best way to truly understand how the algorithms work and to master the art of programming.

The URL for the course : https://www.coursera.org/specializations/data-structures-algorithms

Link to Algorithmic Toolbox course certificate ( Grade : 95% ) : https://www.coursera.org/account/accomplishments/certificate/2KMF5GW3ADLK

