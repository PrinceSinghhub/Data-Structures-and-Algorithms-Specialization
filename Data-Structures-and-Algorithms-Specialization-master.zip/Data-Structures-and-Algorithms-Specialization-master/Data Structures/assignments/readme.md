This folder consists of the weekly assignments for the course data structures.
